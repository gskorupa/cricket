#!/bin/sh
java --add-modules java.activation -jar cricket-1.2.31.jar -r -c config/cricket.json